<section>
    <header class="ds-none">
        <h1>Siga a Clínica Corcini nas Redes Sociais</h1>
    </header>
    <div class="social_media_fix" style="padding: 5px; background: #ffffff;">
        <div class="vertical">
            <img class="social" src="{{asset('images/desktop/icon_instagram_yellow.png')}}" alt="">
            <img class="social" src="{{asset('images/desktop/icon_facebook_yellow.png')}}" alt="">
            <img src="{{asset('images/desktop/line.png')}}" alt="">
            <p style="color: var(--colorSand);">Siga a Clínica Corcini</p>
        </div>
    </div>
</section>
