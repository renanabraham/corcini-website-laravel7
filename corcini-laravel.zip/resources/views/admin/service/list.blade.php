<div style="background: #e6e61b; padding: 30px;">
    <h2>Serviços</h2>
    <hr>
    <a href="/admin/service/create">Novo Servicço</a>

    Serviços
</div>
