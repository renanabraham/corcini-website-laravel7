@extends('admin.master.master')

@section('content')
    <style>
        form {
            width: 100%;
        }

        input {
            width: 50%;
            padding: 10px;
            margin-bottom: 10px;
        }
    </style>
    <form action="/admin/service/store" method="post" autocomplete="off" enctype="multipart/form-data">
        @csrf
        <p>Categoria do serviço</p>
        <input type="text" name="category" placeholder="category" value="{{old('category')}}"><br>
        <p>Título do serviço</p>
        <input type="text" name="title" placeholder="Título" value="{{old('title')}}"><br>
        <p>Subtítulo do serviço</p>
        <input type="text" name="subtitle" placeholder="" value=""><br>
        <p>"Head Line" do serviço</p>
        <input type="text" name="headline" placeholder="" value=""><br>
        <p>Parágrafo 1</p>
        <input type="text" name="p1" placeholder="p1" value=""><br>
        <p>Imagem com posição justificada na esquerda</p>
        <input type="file" name="image1"><br>
        <p>Descrição da imagem justificada na esquerda</p>
        <input type="text" name="image1desc" placeholder="image1desc" value=""><br>
        <p>Parágrafo 2</p>
        <input type="text" name="p2" placeholder="p2" value=""><br>
        <p>Imagem com posição justificada na direita</p>
        <input type="file" name="image2"><br>
        <p>Descrição da imagem justificada na direita</p>
        <input type="text" name="image2desc" placeholder="image2desc" value=""><br>
        <input type="text" name="p3" placeholder="p3" value=""><br>
        <input type="text" name="p4" placeholder="p3" value=""><br>
        <input type="text" name="video_url" placeholder="video_url" value=""><br>
        <input type="text" name="video_desc" placeholder="video_desc" value=""><br>
        <input type="text" name="step1_title" placeholder="step1_title" value=""><br>
        <input type="text" name="step1_content" placeholder="step1_content" value=""><br>
        <input type="text" name="step2_title" placeholder="step2_title" value=""><br>
        <input type="text" name="step2_content" placeholder="step2_content" value=""><br>
        <input type="text" name="step3_title" placeholder="step3_title" value=""><br>
        <input type="text" name="step3_content" placeholder="step3_content" value=""><br>
        <input type="text" name="step4_title" placeholder="step4_title" value=""><br>
        <input type="text" name="step4_content" placeholder="step4_content" value=""><br>
        <button type="submit">Cadastrar</button>
    </form>
@endsection
