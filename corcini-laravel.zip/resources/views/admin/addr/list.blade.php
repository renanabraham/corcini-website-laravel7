<div style="background: #cccccc; padding: 30px;">
    <h2>Endereços de atendimento</h2>
    <hr>
    <a href="/admin/addr/create">Novo Endereço</a>
    @foreach($addrs as $addr)
        <p style="display: flex; align-items: center; justify-content: space-between; flex-wrap: nowrap; font-size: 1.2em;">
            <img src="{{asset('storage/'.$addr->photo)}}" alt="" width="60" height="60"> Editar o
            endereço de <b>{{ $addr->city}}</b> - <a
                href="/admin/addr/edit/{{$addr->id}}">Editar</a></p>
        <hr>
    @endforeach
</div>
