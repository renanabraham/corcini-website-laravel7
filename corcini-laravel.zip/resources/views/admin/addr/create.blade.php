@extends('admin.master.master')

@section('content')
    <form action="/admin/addr/store" method="post" autocomplete="off" enctype="multipart/form-data">
        @csrf
        <input type="file" name="photo"/><br>
        <input type="text" name="city" placeholder="city"><br>
        <input type="text" name="addr" placeholder="addr"><br>
        <input type="text" name="whatsapp" placeholder="whatsapp"><br>
        <input type="text" name="phone" placeholder="whatsapp"><br>
        <button type="submit">Cadastrar</button>
    </form>
@endsection
