@extends('admin.master.master')
@section('title', 'Editar endereço de atendimento')
@section('content')
    <style>
        form{
            width: 100%;
        }
        input{
            width: 50%;
            padding: 10px;
            margin-bottom: 10px;
        }
    </style>
    <form action="/admin/addr/update/{{$addr->id}}" method="post" autocomplete="off" enctype="multipart/form-data">
        @csrf
        <input type="file" name="photo"/><br>
        Cidade: <input type="text" name="city" placeholder="Cidade" value="{{$addr->city}}"><br>
        Endereço: <input type="text" name="addr" placeholder="Endereço" value="{{$addr->addr}}"><br>
        Whatsapp: <input type="text" name="whatsapp" placeholder="Whatsapp:" value="{{$addr->whatsapp}}"><br>
        Telefone: <input type="text" name="phone" placeholder="Telefone:" value="{{$addr->phone}}"><br><BR>
        <button type="submit">ATUALIZAR!</button>
    </form>

    <a href="/admin">< Voltar</a>
@endsection

