@extends('admin.master.master')
@section('title', 'Clínica Corcini - Painel do Site')
@section('content')
    @include('admin.service.list')
    @include('admin.category.list')
    @include('admin.addr.list')
@endsection
