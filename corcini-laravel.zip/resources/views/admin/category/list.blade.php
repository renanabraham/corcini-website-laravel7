<div style="background: #ebebeb; padding: 30px;">
    <h2>Categorias</h2>
    <hr>
    <a href="/admin/category/create">Nova Categoria</a>
    @foreach($categories as $category)
        @if($category->parent == null)
            <hr>
            <p>CATEGORIA: <b>{{$category->title}}</b> - <a href="/admin/category/edit/{{$category->id}}">Editar</a> - <a href="/admin/category/delete/{{$category->id}}" onclick="return confirm('Tem certeza?')">Deletar</a>
            </p>
            <p>DESCRIÇÃO: {{$category->subtitle}}</p>
            <p>Subcategorias: </p>
            @foreach($subCategories as $sub)
                @if($sub->parent == $category->id)

                    <p> - {{$sub->title}} - <a href="/admin/category/edit/{{$sub->id}}">Editar</a> - <a href="/admin/category/delete/{{$sub->id}}" onclick="return confirm('Tem certeza?')">Deletar</a></p>
                @endif
            @endforeach
        @endif
    @endforeach

</div>
