@extends('admin.master.master')

@section('content')
    <style>
        form {
            width: 100%;
        }

        input {
            width: 50%;
            padding: 10px;
            margin-bottom: 10px;
        }
    </style>
    <form action="/admin/category/store" method="post" autocomplete="off" enctype="multipart/form-data">
        @csrf
        <input type="text" name="title" placeholder="Título da Categoria" value="{{old('title')}}"><br>
        <input type="text" name="subtitle" placeholder="Descrição" value="{{old('subtitle')}}"><br>
        <input type="text" name="parent" placeholder="" value="{{old('parent')}}">
        <button type="submit">Cadastrar</button>
    </form>
@endsection
