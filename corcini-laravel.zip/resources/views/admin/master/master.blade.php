<h1>@yield('title')</h1>
<hr>

@yield('content')

<hr>
