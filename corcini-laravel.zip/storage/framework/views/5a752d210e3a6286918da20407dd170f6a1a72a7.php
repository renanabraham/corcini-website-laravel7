<?php $__env->startSection('title', 'Editar endereço de atendimento'); ?>
<?php $__env->startSection('content'); ?>
    <style>
        form{
            width: 100%;
        }
        input{
            width: 50%;
            padding: 10px;
            margin-bottom: 10px;
        }
    </style>
    <form action="/admin/addr/update/<?php echo e($addr->id); ?>" method="post" autocomplete="off" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input type="file" name="photo"/><br>
        Cidade: <input type="text" name="city" placeholder="Cidade" value="<?php echo e($addr->city); ?>"><br>
        Endereço: <input type="text" name="addr" placeholder="Endereço" value="<?php echo e($addr->addr); ?>"><br>
        Whatsapp: <input type="text" name="whatsapp" placeholder="Whatsapp:" value="<?php echo e($addr->whatsapp); ?>"><br>
        Telefone: <input type="text" name="phone" placeholder="Telefone:" value="<?php echo e($addr->phone); ?>"><br><BR>
        <button type="submit">ATUALIZAR!</button>
    </form>

    <a href="/admin">< Voltar</a>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\corcini-laravel\resources\views/admin/addr/edit.blade.php ENDPATH**/ ?>