<div style="background: #cccccc; padding: 30px;">
    <h2>Endereços de atendimento</h2>
    <hr>
    <a href="/admin/addr/create">Novo Endereço</a>
    <?php $__currentLoopData = $addrs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $addr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p style="display: flex; align-items: center; justify-content: space-between; flex-wrap: nowrap; font-size: 1.2em;">
            <img src="<?php echo e(asset('storage/'.$addr->photo)); ?>" alt="" width="60" height="60"> Editar o
            endereço de <b><?php echo e($addr->city); ?></b> - <a
                href="/admin/addr/edit/<?php echo e($addr->id); ?>">Editar</a></p>
        <hr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH C:\laragon\www\corcini-laravel\resources\views/admin/addr/list.blade.php ENDPATH**/ ?>