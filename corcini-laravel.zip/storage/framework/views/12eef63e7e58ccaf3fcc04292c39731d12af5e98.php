<div style="background: #ebebeb; padding: 30px;">
    <h2>Categorias</h2>
    <hr>
    <a href="/admin/category/create">Nova Categoria</a>
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($category->parent == null): ?>
            <hr>
            <p>CATEGORIA: <b><?php echo e($category->title); ?></b> - <a href="/admin/category/edit/<?php echo e($category->id); ?>">Editar</a> - <a href="/admin/category/delete/<?php echo e($category->id); ?>" onclick="return confirm('Tem certeza?')">Deletar</a>
            </p>
            <p>DESCRIÇÃO: <?php echo e($category->subtitle); ?></p>
            <p>Subcategorias: </p>
            <?php $__currentLoopData = $subCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($sub->parent == $category->id): ?>

                    <p> - <?php echo e($sub->title); ?> - <a href="/admin/category/edit/<?php echo e($sub->id); ?>">Editar</a> - <a href="/admin/category/delete/<?php echo e($sub->id); ?>" onclick="return confirm('Tem certeza?')">Deletar</a></p>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
<?php /**PATH C:\laragon\www\corcini-laravel\resources\views/admin/category/list.blade.php ENDPATH**/ ?>