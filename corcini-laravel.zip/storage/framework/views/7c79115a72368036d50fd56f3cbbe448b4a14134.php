<html lang="pt-br">
<head>
    <meta charset="utf-8"/>
    <link rel="icon" href=""/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <link rel="stylesheet" href="assets/css/boot.css"/>
    <!--    <link rel="stylesheet" href="assets/css/style.css"/>-->
    <link rel="stylesheet" href="modules/header/header.css"/>
    <link rel="stylesheet" href="modules/social_fixed/social.css"/>
    <link rel="stylesheet" href="modules/services/services.css"/>
    <link rel="stylesheet" href="modules/slides/slides.css"/>
    <link rel="stylesheet" href="modules/footer/footer.css"/>
    <link rel="stylesheet" href="modules/about/about.css"/>
    <link rel="stylesheet" href="modules/posts/posts.css"/>
    <link rel="stylesheet" href="assets/css/mobile.css"/>

    <title>Clínica Corcini - <?php echo $__env->yieldContent('title'); ?></title>
</head>
<body>

<?php echo $__env->yieldContent('content'); ?>

<!--Plugins-->
<script src="assets/js/jquery.js"></script>
<script src="assets/js/plugins.js"></script>
<!--Template functions-->
<script src="assets/js/functions.js"></script>
<script src="assets/js/scripts.js"></script>

</body>
</html>
<?php /**PATH C:\laragon\www\corcini-laravel\resources\views////master/master.blade.php ENDPATH**/ ?>