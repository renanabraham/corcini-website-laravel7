<h1><?php echo $__env->yieldContent('title'); ?></h1>
<hr>

<?php echo $__env->yieldContent('content'); ?>

<hr>
<?php /**PATH C:\laragon\www\corcini-laravel\resources\views/admin/master/master.blade.php ENDPATH**/ ?>