<?php $__env->startSection('title', 'Editar Categoria'); ?>
<?php $__env->startSection('content'); ?>
    <style>
        form {
            width: 100%;
        }

        input {
            width: 50%;
            padding: 10px;
            margin-bottom: 10px;
        }
    </style>
    <form action="/admin/category/update/<?php echo e($category->id); ?>" method="post" autocomplete="off"
          enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input type="text" name="title" placeholder="Título da Categoria" value="<?php echo e($category->title); ?>"><br>
        <input type="text" name="subtitle" placeholder="Descrição" value="<?php echo e($category->subtitle); ?>"><br>
        <input type="text" name="parent" placeholder="" value="<?php echo e($category->parent); ?>"><br>

        <button type="submit">ATUALIZAR!</button>
    </form>

    <a href="/admin">< Voltar</a>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\corcini-laravel\resources\views/admin/category/edit.blade.php ENDPATH**/ ?>