<?php $__env->startSection('content'); ?>
    <style>
        form {
            width: 100%;
        }

        input {
            width: 50%;
            padding: 10px;
            margin-bottom: 10px;
        }
    </style>
    <form action="/admin/category/store" method="post" autocomplete="off" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input type="text" name="title" placeholder="Título da Categoria" value="<?php echo e(old('title')); ?>"><br>
        <input type="text" name="subtitle" placeholder="Descrição" value="<?php echo e(old('subtitle')); ?>"><br>
        <input type="text" name="parent" placeholder="" value="<?php echo e(old('parent')); ?>">
        <button type="submit">Cadastrar</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\corcini-laravel\resources\views/admin/category/create.blade.php ENDPATH**/ ?>