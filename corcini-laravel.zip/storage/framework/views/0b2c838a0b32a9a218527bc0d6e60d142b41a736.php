<h1>Lista de Endereços!</h1>
<?php $__currentLoopData = $addrs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $addr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo e($addr->city); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\laragon\www\corcini-laravel\resources\views/addrs.blade.php ENDPATH**/ ?>