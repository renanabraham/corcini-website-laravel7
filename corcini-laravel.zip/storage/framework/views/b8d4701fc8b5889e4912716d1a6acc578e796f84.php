<html lang="pt-br">
<head>
    <meta charset="utf-8"/>
    <link rel="icon" href=""/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/boot.css')); ?>"/>
    <!--    <link rel="stylesheet" href="assets/css/style.css"/>-->
    <link rel="stylesheet" href="<?php echo e(asset('modules/header/header.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(asset('modules/social_fixed/social.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(asset('modules/services/services.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(asset('modules/slides/slides.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(asset('modules/footer/footer.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(asset('modules/about/about.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(asset('modules/posts/posts.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/mobile.css')); ?>"/>

    <title>Clínica Corcini - <?php echo $__env->yieldContent('title'); ?></title>
</head>
<body>

<?php echo $__env->yieldContent('content'); ?>

<!--Plugins-->
<script src="<?php echo e(asset('assets/js/jquery.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/plugins.js')); ?>"></script>
<!--Template functions-->
<script src="<?php echo e(asset('assets/js/functions.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/scripts.js')); ?>"></script>

</body>
</html>
<?php /**PATH C:\laragon\www\corcini-laravel\resources\views/master/master.blade.php ENDPATH**/ ?>