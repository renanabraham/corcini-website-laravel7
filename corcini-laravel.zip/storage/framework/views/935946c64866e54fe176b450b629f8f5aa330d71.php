<?php $__env->startSection('content'); ?>
    <form action="/admin/addr/store" method="post" autocomplete="off" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input type="file" name="photo"/><br>
        <input type="text" name="city" placeholder="city"><br>
        <input type="text" name="addr" placeholder="addr"><br>
        <input type="text" name="whatsapp" placeholder="whatsapp"><br>
        <input type="text" name="phone" placeholder="whatsapp"><br>
        <button type="submit">Cadastrar</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\corcini-laravel\resources\views/admin/addr/create.blade.php ENDPATH**/ ?>