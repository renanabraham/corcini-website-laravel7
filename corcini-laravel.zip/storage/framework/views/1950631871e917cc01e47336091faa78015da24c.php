<section id="slide4" class="services_container position-relative">
    <div class="logo_on_mobile_services ds-none">
        <img src="images/desktop/logo_dark.png" alt="">
    </div>
    <div class="logo_dark position-absolute">
        <img class="j_logo_dark ds-none" src="images/desktop/logo_dark.png" alt="">
    </div>
    <div class="content"><!--1170px-->

        <div class="content800"><!--800px-->
            <header>
                <h1 class="title">Descubra um mundo <br/>de muitas possibilidades</h1>
                <div class="tagline">
                    <img src="images/desktop/line_white.png" alt="">
                    <p>Escolha o serviço que você deseja realizar</p>
                </div>
            </header>
        </div>

        <div class="services_items_content accordion">

            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($category->parent == null): ?>
                    <article class="service_item ac-item">
                        <header class="ac-title">
                            <img class="cross ds-none" src="images/desktop/icon_cross.png" alt="">
                            <img class="plus" src="images/desktop/icon_plus.png" alt="">
                            <h1><?php echo e($category->title); ?></h1>
                        </header>
                        <div class="service_item_nav ac-content">
                            <ul>
                                <?php $__currentLoopData = $subCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($sub->parent == $category->id): ?>
                                        <li><a href="<?php echo e($sub->slug); ?>"><?php echo e($sub->title); ?></a></li>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </article>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
</section>
<?php /**PATH C:\laragon\www\corcini-laravel\resources\views/includes/services.blade.php ENDPATH**/ ?>