<?php

namespace App\Http\Controllers;

use App\Addr;
use App\Service;
use Illuminate\Http\Request;
use App\Category;

class SiteController extends Controller
{
    public function home()
    {
        //LISTAGEM DE CATEGORIAS
        $categories = Category::all();
        $bossCategory = Category::where('parent', null)->orderBy('order', 'ASC')->get();
        $subCategories = Category::where('parent', '!=', null)->get();


        //LISTAGEM DE ENDEREÇO DE ATENDIMENTO
        $addrs = Addr::all();


        return view('home', [
            'addrs' => $addrs,
            'categories' => $categories,
            'bossCategory' => $bossCategory,
            'subCategories' => $subCategories
        ]);
    }

    public function nav($slug)
    {
        $categories = Category::all();
        $subCategories = Category::where('parent', '!=', null)->get();
        $category = Category::where('slug', $slug)->first();
        //RELACIONAMENTO
        $services = $category->services()->take(1)->get();

        if ($category) {
            return view('pages.category', [
                'category' => $category,
                'categories' => $categories,
                'subCategories' => $subCategories,
                'services' => $services
                ]);
        } else {
            echo "a categoria " . $slug . " não existe";
        }
    }

    public function category($slug)
    {

    }
}
