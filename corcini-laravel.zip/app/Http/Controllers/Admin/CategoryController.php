<?php

namespace App\Http\Controllers\Admin;

use App\Category;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class CategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $categories = Category::where('parent', null)->get();
        return view('admin.category.create', [
            'categories' => $categories
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $categorySlug = $this->setSlug($request->title);
        $category = new Category();
        $category->parent = $request->parent;
        $category->slug = $categorySlug;
        $category->title = $request->title;
        $category->subtitle = $request->subtitle;
        $category->order = $request->order;
        $category->save();

        return redirect('/admin');
    }

    private function setSlug($title)
    {
        $categorySlug = Str::slug($title);

        $categories = Category::all();
        $t = 0;
        foreach ($categories as $category) {
            if (Str::slug($category->title) === $categorySlug) {
                $t++;
            }
        }

        if ($t > 0) {
            $categorySlug = $categorySlug . '-' . $t;
        }

        return $categorySlug;
    }

    /**
     * Display the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $categories=Category::all();
        $category = Category::where('id', $id)->first();
        if (isset($category)){
            return view('admin.category.edit', [
                'categories' => $categories,
                'category' => $category,
            ]);
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $category = Category::find($id);
        $categorySlug = $this->setSlug($request->title);

        $category->parent = $request->parent;
        $category->slug = $categorySlug;
        $category->title = $request->title;
        $category->subtitle = $request->subtitle;
        $category->order = $request->order;
        $category->save();

        return redirect('/admin');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $category = Category::find($id);

        if ($category){
            $category->delete();
            return redirect('/admin');
        } else {
            return redirect('/admin');
        }

    }
}
