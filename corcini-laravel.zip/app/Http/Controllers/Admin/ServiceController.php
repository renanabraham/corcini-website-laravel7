<?php

namespace App\Http\Controllers\Admin;

use App\Category;
use App\Http\Controllers\Controller;
use App\Service;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class ServiceController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.service.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //dd($request);
        $slug = Str::slug($request->title);
        $service = new Service();

        $service->category = $request->category;
        $service->slug = $slug;
        $service->title = $request->title;
        $service->subtitle = $request->subtitle;
        $service->p1 = $request->p1;
        if ($request->file('image1')){
            $service->image1 = $request->file('image1')->store('public/service');
        } else {
            $service->image1 = null;
        }
        $service->image1desc = $request->image1desc;
        $service->p2 = $request->p2;
        if ($request->file('image2')){
            $service->image2 = $request->file('image2')->store('public/service');
        } else {
            $service->image2 = null;
        }
        $service->image2desc = $request->image2desc;
        $service->p3 = $request->p3;
        $service->p4 = $request->p4;
        $service->video_url = $request->video_url;
        $service->video_desc = $request->video_desc;
        $service->step1_title = $request->step1_title;
        $service->step1_content = $request->step1_content;
        $service->step2_title = $request->step2_title;
        $service->step2_content = $request->step2_content;
        $service->step3_title = $request->step3_title;
        $service->step3_content = $request->step3_content;
        $service->step4_title = $request->step4_title;
        $service->step4_content = $request->step4_content;
        $service->save();

        return redirect('/admin');

    }

    /**
     * Display the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
