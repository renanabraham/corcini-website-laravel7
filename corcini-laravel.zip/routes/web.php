<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'SiteController@home');
Route::get('/servicos/{slug}/', 'SiteController@nav');
Route::get('/servicos/{category}/{service}', 'SiteController@service');

//ADMIN
Route::prefix('admin')->group(function () {

    Route::get('/', 'Admin\HomeController@index');

    //SERVICES
    Route::get('/service/create', 'Admin\ServiceController@create');
    Route::post('/service/store', 'Admin\ServiceController@store');

    //CATEGORIAS
    Route::get('/category/create', 'Admin\CategoryController@create');
    Route::post('/category/store', 'Admin\CategoryController@store');
    Route::get('/category/edit/{id}', 'Admin\CategoryController@edit');
    Route::post('/category/update/{id}', 'Admin\CategoryController@update');
    Route::get('/category/delete/{id}', 'Admin\CategoryController@destroy');

    //ENDEREÇOS
    Route::get('/addr/create', 'Admin\AddrController@create');
    Route::post('/addr/store', 'Admin\AddrController@store');

    Route::get('/addr/edit/{id}', 'Admin\AddrController@edit');
    Route::post('/addr/update/{id}', 'Admin\AddrController@update');
    //################################################################################################################

    //CATEGORIAS
});



