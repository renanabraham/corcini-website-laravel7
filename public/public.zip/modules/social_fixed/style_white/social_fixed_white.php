<section>
    <header class="ds-none">
        <h1>Siga a Clínica Corcini nas Redes Sociais</h1>
    </header>
    <div class="social_media_fix" style="padding: 5px;">
        <div class="vertical">
            <img class="social" src="images/desktop/icon_instagram.png" alt="">
            <img class="social" src="images/desktop/icon_facebook.png" alt="">
            <img src="images/desktop/line_white.png" alt="">
            <p style="color: var(--colorWhite);">Siga a Clínica Corcini</p>
        </div>
    </div>
</section>