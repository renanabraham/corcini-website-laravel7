<!--Plugins-->
<script src="assets/js/jquery.js"></script>
<script src="assets/js/plugins.js"></script>
<!--Template functions-->
<script src="assets/js/functions.js"></script>
<script src="assets/js/scripts.js"></script>
</body>
</html>